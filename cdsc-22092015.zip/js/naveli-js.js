$(document).ready(function(){
      $('.slider').slider({full_width: true});
       $('.modal-trigger').leanModal();
       //$('#modal1').openModal();
       $(".button-collapse").sideNav();
       $('.parallax').parallax();
       $('.materialboxed').materialbox();
    });